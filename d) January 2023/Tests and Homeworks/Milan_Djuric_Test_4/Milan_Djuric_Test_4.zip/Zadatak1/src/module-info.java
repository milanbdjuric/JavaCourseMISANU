/**
 * 
 */
/**
 * @author DJURIC
 *
 */
module Zadatak1 {
}