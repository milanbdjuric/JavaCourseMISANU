package djuric;

public class KorenException extends Exception {
	
	KorenException(String poruka){
		super(poruka);
	}
	

}
